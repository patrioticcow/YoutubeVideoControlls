YouTube(TM) Video Controlls
==============================

YouTube(TM) Video Controlls Chrome App

https://chrome.google.com/webstore/detail/youtube-mouse-controls/odhhfodnkaidhocaaaokdofhkoiahpbn

Simple and No Adds, with  Mouse Controls for YouTube� you can change the volume and seek with your mouse.

How to use
  After installing the app, refresh your YouTube� page. The controls should be active now.
  Hover over the player and use your mouse scroll to change the volume.
  To seek click the middle button once, then scroll. this will move your seek forward or backward in time.

  Thanks for using this app and please let me know if there are any issues or feature requests.

v. 0.9.6
-- Added Volume Only feature
-- Minor fixes

v. 0.9.5
-- volume and seek options page fix

v. 0.9.4
-- adding proper branding

v. 0.9.3
-- adding proper attribution

v. 0.9.2
-- small bux fix

v. 0.9.1
-- added options page. To access it type chrome://extensions in the address bar
     -- Use Volume Controls by default
     -- Use Seek Controls by default
     -- Volume sensitivity
     -- Seek sensitivity

v. 0.1.5
-- bug fix - seek doesn't keep track of the current time
(thanks the community for reporting this bug)

v 0.1.4
-- bug fix #17 - volume not working with the flash player

v 0.1.3
-- code cleanup

v 0.1.2
-- html5 player bug fixed

v 0.1.1
-- initial release
-- scroll up and down to change volume
-- click the middle mouse then scroll up and down to change seek

Copyright (c) 2014 Cristi Citea

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
